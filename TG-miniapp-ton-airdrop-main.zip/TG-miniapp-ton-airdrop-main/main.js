module.exports = {
    price_for_fren: 500,
    price_for_click: 100,
    price_for_transaction: 50000,
    total_frens_for_x2: 3,
    name_jetton: '$YOD',
    name_crypto: 'YOD',
    channel_ru: 'yodton',
    channel_en: 'yod_ton',
    picture_menu: 'AgACAgIAAxkBAAOTZg7s64Pl6d6_YZYwx3ozVws9iX4AAlDdMRuHtHhIx3kCwniQ5EYBAAMCAAN4AAM0BA',
    picture_terms: 'AgACAgIAAxkBAAIGKWYRQoiL453pCFInw-IPVjrMGlsHAAIk1TEb0zqISMxxTQU44n9IAQADAgADeQADNAQ',
    picture_tasks: 'AgACAgIAAxkBAAIGOGYRQzAzjGeTCL6edk20PwYEIOOQAAIp1TEb0zqISJTHPx7YQuloAQADAgADeQADNAQ',
    picture_messaging: 'AgACAgIAAxkBAAINOGYSVftP36Xf9Eq9Ih-f85KZp7L1AAKI2zEb0zqQSA7OaS7q2hXDAQADAgADeQADNAQ',
    transfer: 'https://app.tonkeeper.com/transfer/UQBzKFu3gn7CHrbGnWnWXNZnFinYrnT5ryc34N4G04oQxbit?amount=4000000&text=t',
    buy_tg_premium: 'https://fragment.com/premium/gift',
    info_transfer: 'https://telegra.ph/YOD-DROP-04-06',
    rating_rewards: [19000, 17000, 15000, 13000, 11000, 9000, 7000, 5000, 3000, 1000]
};